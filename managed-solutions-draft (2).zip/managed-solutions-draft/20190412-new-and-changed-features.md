---


copyright:
  years: 2018, 2019
lastupdated: "2019-08-09"


---

{:new_window: target="_blank"} 
{:shortdesc: .shortdesc} 
{:codeblock: .codeblock} 
{:pre: .pre} 
{:screen: .screen} 
{:tsSymptoms: .tsSymptoms} 
{:tsCauses: .tsCauses} 
{:tsResolve: .tsResolve} 
{:tip: .tip} 
{:important: .important} 
{:note: .note} 
{:download: .download} 
{:external: target= .external} 

# 2019.04.12 New and changed features
{: #20190412-new-and-changed-features } 

2019.04.12 New and changed features.
{: shortdesc} 

This section describes new and changed functionality for 2019.04.12.

## Managed Applications Portal enhancements
{: #13658-managed-applications-portal-enhancement } 

  - Servers feature shows servers that have no entitlements
    (entitlements are applications on the operating system).
  - You can select a server and, when you click **view detail** on a
    usage graph, view enhanced graphics for servers' processor, memory,
    and disk utilization. You can zoom in on the information shown.
  - On Overview feature, the alerts tile is redesigned.
  - Improved page load times.
