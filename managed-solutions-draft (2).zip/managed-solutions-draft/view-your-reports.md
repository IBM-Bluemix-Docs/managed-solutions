---


copyright:
  years: 2018, 2019
lastupdated: "2019-08-09"


---

{:new_window: target="_blank"} 
{:shortdesc: .shortdesc} 
{:codeblock: .codeblock} 
{:pre: .pre} 
{:screen: .screen} 
{:tsSymptoms: .tsSymptoms} 
{:tsCauses: .tsCauses} 
{:tsResolve: .tsResolve} 
{:tip: .tip} 
{:important: .important} 
{:note: .note} 
{:download: .download} 
{:external: target= .external} 

# View your reports
{: #view-your-reports } 

Learn how to view reports for your services.
{: shortdesc} 

You can view all the reports that are available for your services.

1.  Open IBM Cloud Console.

2.  From the list next to <svg aria-label="pencil with paper"
    alt="pencil with paper" viewBox="0 0 32 32" width="16"
    height="16"><path d="M22 22v6H6V4h10V2H6a2 2 0 0 0-2 2v24a2 2 0 0
    0 2 2h16a2 2 0 0 0 2-2v-6z"/><path d="M29.537 5.76L26.24
    2.463a1.58 1.58 0 0 0-2.236 0L10 16.467V22h5.533L29.537 7.995a1.58
    1.58 0 0 0 0-2.235zM14.704 20H12v-2.704l9.44-9.441 2.705
    2.704zM25.56 9.145l-2.704-2.704 2.267-2.267 2.704
    2.704z"/></svg>, select the account with your managed
    applications.

3.  Click **Menu**, ≡.

4.  Select **Managed Solutions**.
    
    The Managed Solutions menu appears.

5.  Click **Insights**.
    
    The Insights choices appear under **Insights** in the navigation
    panel.

6.  Click **Reports**.
    
    The Reports page appears.

7.  Hover over the report you want and click **Generate Report**.
    
    The generated report appears.
