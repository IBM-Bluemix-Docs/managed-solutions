---


copyright:
  years: 2018, 2019
lastupdated: "2019-08-09"


---

{:new_window: target="_blank"} 
{:shortdesc: .shortdesc} 
{:codeblock: .codeblock} 
{:pre: .pre} 
{:screen: .screen} 
{:tsSymptoms: .tsSymptoms} 
{:tsCauses: .tsCauses} 
{:tsResolve: .tsResolve} 
{:tip: .tip} 
{:important: .important} 
{:note: .note} 
{:download: .download} 
{:external: target= .external} 

# 2019.03.15 New and changed features
{: #20190315-new-and-changed-features } 

2019.03.15 New and changed features.
{: shortdesc} 

This section describes new and changed functionality for 2019.03.15.

## Managed Applications Portal enhancements
{: #13618-managed-applications-portal-enhancement } 

  - Overview feature has support tiles even if you have no
    application-specific servers.
  - You can view details regarding alerts and links to their associated
    tickets under **Health**. Overview feature has an alerts tile that
    shows the number of current and historical alerts.
  - You can select and view enhanced graphics for servers' processor,
    memory, and disk utilization by clicking **view details** on the
    server page. You can export those graphs to a PDF or CSV file.
  - You cannot add or remove attachments to a ticket after it has
    advanced to the assess phase. This ensures the scope of the request
    does ot change during review and delivery. You can use the
    communication log or contact your Delivery Project Executive if a
    change is needd after the assess phase begins.
