---


copyright:
  years: 2018, 2019
lastupdated: "2019-08-09"


---

{:new_window: target="_blank"} 
{:shortdesc: .shortdesc} 
{:codeblock: .codeblock} 
{:pre: .pre} 
{:screen: .screen} 
{:tsSymptoms: .tsSymptoms} 
{:tsCauses: .tsCauses} 
{:tsResolve: .tsResolve} 
{:tip: .tip} 
{:important: .important} 
{:note: .note} 
{:download: .download} 
{:external: target= .external} 

# Application programming interface specifications
{: #application-programming-interface-specificati } 

Go to the application programming interface specifications.
{: shortdesc} 

[Core API documentation](https://169.46.176.94/explorer/#/instance){: external}

[SAP API
documentation](https://sap-api-customer.bluemix.net/sap/v1/docs/){: external}

[Oracle API
documentation](https://api.managed-solutions.cloud.ibm.com/oracle/v1/docs){: external}

[Metrics API
documentation](https://api.managed-solutions.cloud.ibm.com/metrics/v1/docs){: external}

[Health API
documentation](https://api.managed-solutions.cloud.ibm.com/health/v1/docs){: external}

[Support API
documentation](https://api.managed-solutions.cloud.ibm.com/support/v1/docs){: external}

[Account Management API
documentation](https://api.managed-solutions.cloud.ibm.com/acct-mgmt/v1/docs){: external}

[Application Registry API
documentation](https://api.managed-solutions.cloud.ibm.com/app-registry/v1/docs){: external}
