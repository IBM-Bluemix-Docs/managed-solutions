---


copyright:
  years: 2018, 2019
lastupdated: "2020-01-00"


---

{:new_window: target="_blank"} 
{:shortdesc: .shortdesc} 
{:codeblock: .codeblock} 
{:pre: .pre} 
{:screen: .screen} 
{:tsSymptoms: .tsSymptoms} 
{:tsCauses: .tsCauses} 
{:tsResolve: .tsResolve} 
{:tip: .tip} 
{:important: .important} 
{:note: .note} 
{:download: .download} 
{:external: target= .external} 

# 2020-01-00 New and changed features
{: #20200100-new-and-changed-features } 

2020-01-00 New and changed features.
{: shortdesc} 

This section describes new and changed functionality for 2020-01-00.

## Managed Applications Portal enhancements

  - Change Request module is enhanced with following extended fields: Category, Priority, Risk, Justification, 
    Impact Assessment, Change/Implementation Plan, Backout Plan, Test Plan and Communication Plan.
