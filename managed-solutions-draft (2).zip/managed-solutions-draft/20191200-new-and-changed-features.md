---


copyright:
  years: 2018, 2019
lastupdated: "2019-12-00"


---

{:new_window: target="_blank"} 
{:shortdesc: .shortdesc} 
{:codeblock: .codeblock} 
{:pre: .pre} 
{:screen: .screen} 
{:tsSymptoms: .tsSymptoms} 
{:tsCauses: .tsCauses} 
{:tsResolve: .tsResolve} 
{:tip: .tip} 
{:important: .important} 
{:note: .note} 
{:download: .download} 
{:external: target= .external} 

# 2019.12.00 New and changed features
{: #20191200-new-and-changed-features } 

2019.12.00 New and changed features.
{: shortdesc} 

This section describes new and changed functionality for 2019.12.00.

## Managed Applications Portal enhancements

  - To help business users traveling between different time zones, Local time zone stamp is displayed while creating and viewing change 
    case.  This is to let the users know that they are setting the time in their local time zone.
  -	Solution Management is implemented in Alerts (Health portal) and Alerts Widget to support users with multiple contracts have 
    specific accesses defined for their contracts.
  - As part of Solution Management implementation in Support portal, users whose contracts are IAM enabled will be able to add Change 
    Approvers and add users to the watchlist. 
  - CPU Consumption Type field is added to the Servers List and in the Server Details page.  
