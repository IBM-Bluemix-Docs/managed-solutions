---


copyright:
  years: 2018, 2019
lastupdated: "2019-08-09"


---

{:new_window: target="_blank"} 
{:shortdesc: .shortdesc} 
{:codeblock: .codeblock} 
{:pre: .pre} 
{:screen: .screen} 
{:tsSymptoms: .tsSymptoms} 
{:tsCauses: .tsCauses} 
{:tsResolve: .tsResolve} 
{:tip: .tip} 
{:important: .important} 
{:note: .note} 
{:download: .download} 
{:external: target= .external} 

# 2019.02.15 New and changed features
{: #20190215-new-and-changed-features } 

2019.02.15 New and changed features.
{: shortdesc} 

This section describes new and changed functionality for 2019.02.15.

## Managed Applications Portal enhancements
{: #13564-managed-applications-portal-enhancement } 

  - For users with access to multiple customer accounts, clicking a
    ticket link for another account switches you to that account and
    ticket emails sent from ServiceNow open directly without manually
    switching accounts.
  - In service support tickets, you can search tickets for configuration
    items. Results include tickets where the configuration item is
    anywhere on the list of configuration items.
